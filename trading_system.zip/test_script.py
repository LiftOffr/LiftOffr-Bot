print("Running standalone test script")
